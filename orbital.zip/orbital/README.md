# Orbital — Hidden World

Discover underrated places by budget, with hidden gems, local food and local tips.
Owned and created by **Saim Patel**.

A static website (HTML + CSS + vanilla JS). No build step, no dependencies, no sign-up.

## Features

- 3D orbital ring of destinations (drag, flick, hover; visuals / zoom / spacing controls)
- Explore by budget: daily budget slider, travel style, region, travel month, vibe chips, search, sort
- 16 places (India + Nepal) with hidden gems, local food, local tips, best months and how to get there
- Place detail window with tabs, cost calculator and Google Maps link
- Save places to **My Orbit**, plan costs for days / travelers / style, copy or print the plan
- Find-your-orbit quiz (vibe, budget, season, how hidden)
- Local food finder across all destinations
- Community: submit your own hidden gem, rate, upvote, filter, export JSON (saved in the browser)
- Global search (`Ctrl/Cmd + K` or `/`), share links (`#p/chopta`), "Surprise me"
- Keyboard accessible, reduced-motion support, mobile responsive
- PWA: installable and works offline after the first visit

## Project structure

```
index.html            page
css/style.css         styles
js/data.js            destinations (edit this to add places)
js/app.js             all interactivity
sw.js                 offline cache
manifest.webmanifest  PWA manifest
favicon.svg  404.html  robots.txt  .nojekyll  LICENSE
.github/workflows/pages.yml   auto-deploy to GitHub Pages
```

## Deploy on GitHub Pages

1. Create a new repository on GitHub, e.g. `orbital` (public).
2. Upload **all files and folders** from this project (keep the folder structure, including the hidden `.github` folder and `.nojekyll`).
   Or from a terminal inside this folder:
   ```bash
   git init
   git add .
   git commit -m "Orbital: Hidden World"
   git branch -M main
   git remote add origin https://github.com/<your-username>/orbital.git
   git push -u origin main
   ```
3. In the repo go to **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. The included workflow runs on every push to `main`. After about a minute your site is live at
   `https://<your-username>.github.io/orbital/`.

Tip: if you do not want to use Actions, choose **Source: Deploy from a branch → main → / (root)** instead. Both work.

## Add or edit a destination

Open `js/data.js` and copy an existing object. Fields: `id`, `name`, `state`, `country`, `region`, `vibes`,
`hidden` (1–5), `budget` (`low`/`mid`/`high` INR per person per day), `months` (1–12), `tagline`, `desc`,
`colors`, `art` (`mountain`, `beach`, `desert`, `forest`, `river`, `canyon`, `heritage`), `from`, `gems`, `food`, `tips`.
Artwork is generated automatically, so no images are needed.

## Notes

- Budgets are approximate planning figures, not quotes. Verify prices, permits (ILP etc.) and road/season conditions before travelling.
- Community entries are stored in each visitor's own browser (localStorage). For shared, public submissions you would need a backend
  (for example Firebase, Supabase or a form service); the form in `js/app.js` is where you would plug it in.
- Fonts load from Google Fonts; the site still works with fallback fonts if offline.
- Visual style inspired by the free [Tooplate Orbital](https://www.tooplate.com/view/2167-orbital) template.

© 2026 Saim Patel. All rights reserved.
